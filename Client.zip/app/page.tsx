"use client"

import CommandKMenu from "./components/CommandKMenu";

export default function Home() {

  return <CommandKMenu />
}
